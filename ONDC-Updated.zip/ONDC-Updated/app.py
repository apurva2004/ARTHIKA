from dotenv import load_dotenv
import streamlit as st
import os
import google.generativeai as genai

load_dotenv()
api_key = os.getenv("GOOGLE_API_KEY")
genai.configure(api_key=api_key)
model = genai.GenerativeModel("gemini-pro")


system_prompt = (
   """you are a highly knowledgeable assistant specializing in the Open Network for Digital Commerce (ONDC). 
      Your role is to assist users by providing clear and concise answers about ONDC's functionalities, 
      including bulk product uploads, dynamic pricing, inventory management, and product categorization.
      Use data-driven insights and provide examples wherever relevant, drawing from official sources such as data.gov.in.
      Ensure your responses focus on the impact of these functionalities on operational efficiency, market accessibility, and inclusivity for sellers. 
      If users ask for detailed explanations, provide step-by-step guidance. Your tone should be professional, informative, and approachable, making complex concepts easy to understand.
"""
)

chat = model.start_chat(history=[])

def get_gemini_response(question):
    """Get a response from Gemini."""
    if not chat.history:  
        response = chat.send_message(f"{system_prompt}\nUser: {question}", stream=True)
    else:
        response = chat.send_message(question, stream=True)
    

    full_response = ""
    for chunk in response:
        full_response += chunk.text
    return full_response


def chatbot_section():
    """Renders the chatbot section at the bottom of the app."""
    st.subheader("Chat with ARTHIKA Assistant")

    # Initialize chat history in session state
    if 'chat_history' not in st.session_state:
        st.session_state['chat_history'] = []

    # Input for user messages
    if user_input := st.chat_input("Type your message here..."):
        st.session_state['chat_history'].append(("user", user_input))

        response = get_gemini_response(user_input)
        st.session_state['chat_history'].append(("assistant", response))

    for role, text in st.session_state['chat_history']:
        with st.chat_message(role):
            st.markdown(text)