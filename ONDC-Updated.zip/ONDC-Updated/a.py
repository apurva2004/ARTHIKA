import streamlit as st
import pandas as pd
from pymongo import MongoClient
from pymongo.errors import CollectionInvalid
import requests  # For API calls
import pytesseract
from PIL import Image
import fitz  # PyMuPDF for PDF parsing
import pdfplumber
import docx
import io
import re
import tempfile

# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')
db = client['ondc_products']

# Define collections
products_collection = db['products']
categories_collection = db['categories']

# CSV validation
def validate_csv(df):
    required_columns = ['product_name', 'description', 'price', 'quantity', 'categories']
    return all(col in df.columns for col in required_columns)

# Save products to MongoDB
def save_products(products):
    result = products_collection.insert_many(products)
    return len(result.inserted_ids)

# Process CSV file
def process_csv(file):
    df = pd.read_csv(file)
    if validate_csv(df):
        products = df.to_dict('records')
        for product in products:
            product['price'] = float(product['price'])
            product['quantity'] = int(product['quantity'])
            product['categories'] = [cat.strip() for cat in product['categories'].split(',')]
        return products
    return None

# Process PDF file (using pdfplumber and fitz)
def process_pdf(file):
    pdf_text = ''
    with pdfplumber.open(file) as pdf:
        for page in pdf.pages:
            pdf_text += page.extract_text()
    return extract_products_from_text(pdf_text)

# Process DOCX file (using python-docx)
def process_docx(file):
    doc = docx.Document(file)
    doc_text = ''
    for para in doc.paragraphs:
        doc_text += para.text + '\n'
    return extract_products_from_text(doc_text)

# Process image file using Tesseract OCR
def process_image(image):
    # Convert image to text using Tesseract
    text = pytesseract.image_to_string(image)
    return extract_products_from_text(text)

# Extract product information from extracted text
def extract_products_from_text(text):
    # Regex to capture product details
    # Assumes format of the text like: Product Name | Description | Price | Quantity | Categories
    product_pattern = r"(?P<product_name>[\w\s]+)\s*\|\s*(?P<description>[\w\s]+)\s*\|\s*(?P<price>\d+(\.\d{1,2})?)\s*\|\s*(?P<quantity>\d+)\s*\|\s*(?P<categories>[\w, ]+)"
    
    matches = re.findall(product_pattern, text)
    
    products = []
    for match in matches:
        product = {
            'product_name': match[0].strip(),
            'description': match[1].strip(),
            'price': float(match[2].strip()),
            'quantity': int(match[3].strip()),
            'categories': [cat.strip() for cat in match[4].split(',')]
        }
        products.append(product)
    return products

# Add a new category
def add_category(category_name):
    if not categories_collection.find_one({"name": category_name}):
        categories_collection.insert_one({"name": category_name})

# Get all categories
def get_all_categories():
    return [cat['name'] for cat in categories_collection.find()]

# Add a new category
def add_category(category_name):
    if not categories_collection.find_one({"name": category_name}):
        categories_collection.insert_one({"name": category_name})

# Search products by attribute
def search_products(query):
    search_query = {
        "$or": [
            {"product_name": {"$regex": query, "$options": "i"}},
            {"description": {"$regex": query, "$options": "i"}},
            {"categories": {"$regex": query, "$options": "i"}}
        ]
    }
    return list(products_collection.find(search_query))

# Fetch district-specific market data from API
def fetch_district_data(district):
    url = "https://api.data.gov.in/resource/35985678-0d79-46b4-9ed6-6f13308a1d24"
    params = {
        "api-key": "579b464db66ec23bdd0000014f0adeb46e5743027d63ff9375737149",
        "format": "json",
        "filters[District.keyword]": district
    }
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        data = response.json()
        return data.get("records", [])
    except requests.exceptions.RequestException as e:
        st.error(f"An error occurred while fetching data: {e}")
        return []

# Fetch commodity-specific market data from API
def fetch_commodity_data(commodity):
    url = "https://api.data.gov.in/resource/9ef84268-d588-465a-a308-a864a43d0070"
    params = {
        "api-key": "579b464db66ec23bdd0000014f0adeb46e5743027d63ff9375737149",
        "format": "json",
        "filters[commodity]": commodity
    }
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        data = response.json()
        return data.get("records", [])
    except requests.exceptions.RequestException as e:
        st.error(f"An error occurred while fetching commodity data: {e}")
        return []

# Fetch news articles for a product
def fetch_news_articles(query, api_key="your_news_api_key"):
    """
    Fetch news articles related to a specific product using the News API.
    :param query: The product name or keyword to search for.
    :param api_key: Your API key for the News API.
    :return: List of news articles or an error message.
    """
    url = f"https://newsapi.org/v2/everything?q={query}&apiKey={api_key}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()
        return data.get("articles", [])
    except requests.exceptions.RequestException as e:
        st.error(f"An error occurred while fetching news: {e}")
        return []

# Main Streamlit application
def main():
    st.title("Bulk Product Upload, Market Data Viewer, and News Fetcher for ONDC-like Platform")

    # Sidebar menu options
    menu = ["Upload Products", "Manage Categories", "View Products", "Search Products", "Fetch Market Data", "Product News"]
    choice = st.sidebar.selectbox("Menu", menu)

    if choice == "Upload Products":
        uploaded_files = st.file_uploader("Choose Files", type=["csv", "pdf", "docx", "jpg", "jpeg", "png"], accept_multiple_files=True)

        if uploaded_files:
            all_products = []
            invalid_files = []

            for uploaded_file in uploaded_files:
                file_type = uploaded_file.type.split("/")[1]

                if file_type == "csv":
                    products = process_csv(uploaded_file)
                    if products:
                        all_products.extend(products)
                        st.success(f"File '{uploaded_file.name}' successfully processed as CSV.")
                    else:
                        invalid_files.append(uploaded_file.name)
                        st.error(f"Invalid CSV format in file '{uploaded_file.name}'.")

                elif file_type == "pdf":
                    products = process_pdf(uploaded_file)
                    if products:
                        all_products.extend(products)
                        st.success(f"File '{uploaded_file.name}' successfully processed as PDF.")
                    else:
                        invalid_files.append(uploaded_file.name)
                        st.error(f"Failed to extract products from PDF file '{uploaded_file.name}'.")

                elif file_type == "docx":
                    products = process_docx(uploaded_file)
                    if products:
                        all_products.extend(products)
                        st.success(f"File '{uploaded_file.name}' successfully processed as DOCX.")
                    else:
                        invalid_files.append(uploaded_file.name)
                        st.error(f"Failed to extract products from DOCX file '{uploaded_file.name}'.")

                elif file_type in ["jpg", "jpeg", "png"]:
                    image = Image.open(uploaded_file)
                    products = process_image(image)
                    if products:
                        all_products.extend(products)
                        st.success(f"File '{uploaded_file.name}' successfully processed as an image.")
                    else:
                        invalid_files.append(uploaded_file.name)
                        st.error(f"Failed to extract products from image file '{uploaded_file.name}'.")

            # Display feedback
            with st.expander("Processed Files Summary"):
                st.markdown("### Valid Files")
                st.write(f"{len(all_products)} products ready for upload from:")
                st.write([file.name for file in uploaded_files if file.name not in invalid_files])

                st.markdown("### Invalid Files")
                if invalid_files:
                    st.write(invalid_files)
                else:
                    st.write("No invalid files detected.")

            # Upload button
            if all_products:
                st.write(f"Total products ready to upload: {len(all_products)}")
                if st.button("Upload All Products"):
                    try:
                        for product in all_products:
                            for category in product['categories']:
                                add_category(category)
                        uploaded_count = save_products(all_products)
                        st.success(f"{uploaded_count} products have been uploaded successfully to MongoDB!")
                    except Exception as e:
                        st.error(f"An error occurred while uploading products: {str(e)}")
            else:
                st.warning("No valid products to upload. Please check your files and try again.")

    elif choice == "Manage Categories":
        st.subheader("Manage Categories")
        new_category = st.text_input("Add a new category")
        if st.button("Add Category"):
            if new_category:
                add_category(new_category)
                st.success(f"Category '{new_category}' added successfully!")
            else:
                st.warning("Please enter a category name.")

        st.subheader("Existing Categories")
        categories = get_all_categories()
        if categories:
            st.markdown("### Categories:")
            for category in categories:
                st.markdown(f"`{category}` ", unsafe_allow_html=True)
        else:
            st.write("No categories available.")

    elif choice == "View Products":
        st.subheader("View Products")
        categories = get_all_categories()
        selected_category = st.multiselect("Filter by category", categories)

        query = {"categories": {"$in": selected_category}} if selected_category else {}
        products = list(products_collection.find(query, {'_id': 0}))

        if products:
            st.markdown(f"### Showing {len(products)} Products")
            df = pd.DataFrame(products)
            st.dataframe(df)
        else:
            st.warning("No products found for the selected categories.")

    elif choice == "Search Products":
        st.subheader("Search Products by Attributes")
        search_term = st.text_input("Enter a search term (product name, description, category):")

        if search_term:
            search_results = search_products(search_term)
            if search_results:
                st.write(f"Search results for '{search_term}':")
                for product in search_results:
                    with st.expander(product['product_name']):
                        st.markdown(f"**Description**: {product['description']}")
                        st.markdown(f"**Price**: ₹{product['price']}")
                        st.markdown(f"**Quantity**: {product['quantity']}")
                        st.markdown(f"**Category**: {product['category']}")

            else:
                st.warning(f"No products found for '{search_term}'")

    elif choice == "Fetch Market Data":
        st.subheader("Fetch Market Data")
        search_option = st.radio("Search By", ("District", "Commodity"))

        if search_option == "District":
            district = st.text_input("Enter district name")
            if district:
                market_data = fetch_district_data(district)
                if market_data:
                    st.write(f"### Market Data for District: **{district}**")
                    if len(market_data) > 0:
                        st.info(f"Total records found: {len(market_data)}")
                        # Display data in an interactive table
                        st.dataframe(pd.DataFrame(market_data))
                        # Show key statistics
                        st.write("### Highlights")
                        avg_price = pd.DataFrame(market_data).get("modal_price", pd.Series()).astype(float).mean()
                        st.metric("Average Price", f"₹{avg_price:.2f}" if not pd.isnull(avg_price) else "N/A")
                    else:
                        st.warning("No data available for the selected district.")
                else:
                    st.error("No market data found or an error occurred.")

        elif search_option == "Commodity":
            commodity = st.text_input("Enter commodity name (e.g., rice, wheat, etc.)")
            if commodity:
                commodity_data = fetch_commodity_data(commodity)
                if commodity_data:
                    st.write(f"### Market Data for Commodity: **{commodity}**")
                    if len(commodity_data) > 0:
                        st.info(f"Total records found: {len(commodity_data)}")
                        st.dataframe(pd.DataFrame(commodity_data))
                        # Show key statistics
                        st.write("### Highlights")
                        avg_price = pd.DataFrame(commodity_data).get("modal_price", pd.Series()).astype(float).mean()
                        st.metric("Average Price", f"₹{avg_price:.2f}" if not pd.isnull(avg_price) else "N/A")
                    else:
                        st.warning("No data available for the selected commodity.")
                else:
                    st.error("No market data found or an error occurred.")

    elif choice == "Product News":
        st.subheader("Fetch News Articles for Products")

        product_name = st.text_input("Enter the product name to search for news:")

        if st.button("Fetch News"):
            if product_name:
                api_key = "143716419f1241a0ac09f7a77e3f1576"  # Replace with your News API key
                news_articles = fetch_news_articles(product_name, api_key)

                if news_articles:
                    st.write(f"### News articles related to '{product_name}':")
                    for article in news_articles[:10]:  # Limit to 10 articles for display
                        st.markdown(f"**Title:** {article['title']}")
                        st.markdown(f"**Description:** {article['description']}")
                        st.markdown(f"[Read More]({article['url']})\n---")
                else:
                    st.warning(f"No news articles found for '{product_name}'.")
            else:
                st.warning("Please enter a product name.")

if __name__ == "__main__":
    main()















import streamlit as st
import pandas as pd
from pymongo import MongoClient
from pymongo.errors import CollectionInvalid
import requests  # For API calls
import pytesseract
from PIL import Image
import fitz  # PyMuPDF for PDF parsing
import pdfplumber
import docx
import io
import re
import tempfile

# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')
db = client['ondc_products']

# Define collections
products_collection = db['products']
categories_collection = db['categories']

# CSV validation
def validate_csv(df):
    required_columns = ['product_name', 'description', 'price', 'quantity', 'categories']
    return all(col in df.columns for col in required_columns)

# Save products to MongoDB
def save_products(products):
    result = products_collection.insert_many(products)
    return len(result.inserted_ids)

# Process CSV file
def process_csv(file):
    df = pd.read_csv(file)
    if validate_csv(df):
        products = df.to_dict('records')
        for product in products:
            product['price'] = float(product['price'])
            product['quantity'] = int(product['quantity'])
            product['categories'] = [cat.strip() for cat in product['categories'].split(',')]
        return products
    return None

# Process PDF file (using pdfplumber and fitz)
def process_pdf(file):
    pdf_text = ''
    with pdfplumber.open(file) as pdf:
        for page in pdf.pages:
            pdf_text += page.extract_text()
    return extract_products_from_text(pdf_text)

# Process DOCX file (using python-docx)
def process_docx(file):
    doc = docx.Document(file)
    doc_text = ''
    for para in doc.paragraphs:
        doc_text += para.text + '\n'
    return extract_products_from_text(doc_text)

# Process image file using Tesseract OCR
def process_image(image):
    # Convert image to text using Tesseract
    text = pytesseract.image_to_string(image)
    return extract_products_from_text(text)

# Extract product information from extracted text
def extract_products_from_text(text):
    # Regex to capture product details
    # Assumes format of the text like: Product Name | Description | Price | Quantity | Categories
    product_pattern = r"(?P<product_name>[\w\s]+)\s*\|\s*(?P<description>[\w\s]+)\s*\|\s*(?P<price>\d+(\.\d{1,2})?)\s*\|\s*(?P<quantity>\d+)\s*\|\s*(?P<categories>[\w, ]+)"
    
    matches = re.findall(product_pattern, text)
    
    products = []
    for match in matches:
        product = {
            'product_name': match[0].strip(),
            'description': match[1].strip(),
            'price': float(match[2].strip()),
            'quantity': int(match[3].strip()),
            'categories': [cat.strip() for cat in match[4].split(',')]
        }
        products.append(product)
    return products

# Add a new category
def add_category(category_name):
    if not categories_collection.find_one({"name": category_name}):
        categories_collection.insert_one({"name": category_name})

# Get all categories
def get_all_categories():
    return [cat['name'] for cat in categories_collection.find()]

# Add a new category
def add_category(category_name):
    if not categories_collection.find_one({"name": category_name}):
        categories_collection.insert_one({"name": category_name})

# Search products by attribute
def search_products(query):
    search_query = {
        "$or": [
            {"product_name": {"$regex": query, "$options": "i"}},
            {"description": {"$regex": query, "$options": "i"}},
            {"categories": {"$regex": query, "$options": "i"}}
        ]
    }
    return list(products_collection.find(search_query))

# Fetch district-specific market data from API
def fetch_district_data(district):
    url = "https://api.data.gov.in/resource/35985678-0d79-46b4-9ed6-6f13308a1d24"
    params = {
        "api-key": "579b464db66ec23bdd0000014f0adeb46e5743027d63ff9375737149",
        "format": "json",
        "filters[District.keyword]": district
    }
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        data = response.json()
        return data.get("records", [])
    except requests.exceptions.RequestException as e:
        st.error(f"An error occurred while fetching data: {e}")
        return []

# Fetch commodity-specific market data from API
def fetch_commodity_data(commodity):
    url = "https://api.data.gov.in/resource/9ef84268-d588-465a-a308-a864a43d0070"
    params = {
        "api-key": "579b464db66ec23bdd0000014f0adeb46e5743027d63ff9375737149",
        "format": "json",
        "filters[commodity]": commodity
    }
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        data = response.json()
        return data.get("records", [])
    except requests.exceptions.RequestException as e:
        st.error(f"An error occurred while fetching commodity data: {e}")
        return []

# Fetch news articles for a product
def fetch_news_articles(query, api_key="your_news_api_key"):
    """
    Fetch news articles related to a specific product using the News API.
    :param query: The product name or keyword to search for.
    :param api_key: Your API key for the News API.
    :return: List of news articles or an error message.
    """
    url = f"https://newsapi.org/v2/everything?q={query}&apiKey={api_key}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()
        return data.get("articles", [])
    except requests.exceptions.RequestException as e:
        st.error(f"An error occurred while fetching news: {e}")
        return []

# Main Streamlit application
def main():
    st.title("Bulk Product Upload, Market Data Viewer, and News Fetcher for ONDC-like Platform")

    # Sidebar menu options
    menu = ["Upload Products", "Manage Categories", "View Products", "Search Products", "Fetch Market Data", "Product News"]
    choice = st.sidebar.selectbox("Menu", menu)

    if choice == "Upload Products":
        uploaded_files = st.file_uploader("Choose Files", type=["csv","xlsx"], accept_multiple_files=True)

        if uploaded_files:
            all_products = []
            invalid_files = []

            for uploaded_file in uploaded_files:
                file_type = uploaded_file.type.split("/")[1]

                if file_type == "csv":
                    products = process_csv(uploaded_file)
                    if products:
                        all_products.extend(products)
                        st.success(f"File '{uploaded_file.name}' successfully processed as CSV.")
                    else:
                        invalid_files.append(uploaded_file.name)
                        st.error(f"Invalid CSV format in file '{uploaded_file.name}'.")

                elif file_type == "pdf":
                    products = process_pdf(uploaded_file)
                    if products:
                        all_products.extend(products)
                        st.success(f"File '{uploaded_file.name}' successfully processed as PDF.")
                    else:
                        invalid_files.append(uploaded_file.name)
                        st.error(f"Failed to extract products from PDF file '{uploaded_file.name}'.")

                elif file_type == "docx":
                    products = process_docx(uploaded_file)
                    if products:
                        all_products.extend(products)
                        st.success(f"File '{uploaded_file.name}' successfully processed as DOCX.")
                    else:
                        invalid_files.append(uploaded_file.name)
                        st.error(f"Failed to extract products from DOCX file '{uploaded_file.name}'.")

                elif file_type in ["jpg", "jpeg", "png"]:
                    image = Image.open(uploaded_file)
                    products = process_image(image)
                    if products:
                        all_products.extend(products)
                        st.success(f"File '{uploaded_file.name}' successfully processed as an image.")
                    else:
                        invalid_files.append(uploaded_file.name)
                        st.error(f"Failed to extract products from image file '{uploaded_file.name}'.")

            # Display feedback
            with st.expander("Processed Files Summary"):
                st.markdown("### Valid Files")
                st.write(f"{len(all_products)} products ready for upload from:")
                st.write([file.name for file in uploaded_files if file.name not in invalid_files])

                st.markdown("### Invalid Files")
                if invalid_files:
                    st.write(invalid_files)
                else:
                    st.write("No invalid files detected.")

            # Upload button
            if all_products:
                st.write(f"Total products ready to upload: {len(all_products)}")
                if st.button("Upload All Products"):
                    try:
                        for product in all_products:
                            for category in product['categories']:
                                add_category(category)
                        uploaded_count = save_products(all_products)
                        st.success(f"{uploaded_count} products have been uploaded successfully to MongoDB!")
                    except Exception as e:
                        st.error(f"An error occurred while uploading products: {str(e)}")
            else:
                st.warning("No valid products to upload. Please check your files and try again.")

    elif choice == "Manage Categories":
        st.subheader("Manage Categories")
        new_category = st.text_input("Add a new category")
        if st.button("Add Category"):
            if new_category:
                add_category(new_category)
                st.success(f"Category '{new_category}' added successfully!")
            else:
                st.warning("Please enter a category name.")

        st.subheader("Existing Categories")
        categories = get_all_categories()
        if categories:
            st.markdown("### Categories:")
            for category in categories:
                st.markdown(f"`{category}` ", unsafe_allow_html=True)
        else:
            st.write("No categories available.")

    elif choice == "View Products":
        st.subheader("View Products")
        categories = get_all_categories()
        selected_category = st.multiselect("Filter by category", categories)

        query = {"categories": {"$in": selected_category}} if selected_category else {}
        products = list(products_collection.find(query, {'_id': 0}))

        if products:
            st.markdown(f"### Showing {len(products)} Products")
            df = pd.DataFrame(products)
            st.dataframe(df)
        else:
            st.warning("No products found for the selected categories.")

    elif choice == "Search Products":
        st.subheader("Search Products by Attributes")
        search_term = st.text_input("Enter a search term (product name, description, category):")

        if search_term:
            search_results = search_products(search_term)
            if search_results:
                st.write(f"Search results for '{search_term}':")
                for product in search_results:
                    with st.expander(product['product_name']):
                        st.markdown(f"**Description**: {product['description']}")
                        st.markdown(f"**Price**: ₹{product['price']}")
                        st.markdown(f"**Quantity**: {product['quantity']}")
                        st.markdown(f"**Category**: {product['category']}")

            else:
                st.warning(f"No products found for '{search_term}'")

    elif choice == "Fetch Market Data":
        st.subheader("Fetch Market Data")
        search_option = st.radio("Search By", ("District", "Commodity"))

        if search_option == "District":
            district = st.text_input("Enter district name")
            if district:
                market_data = fetch_district_data(district)
                if market_data:
                    st.write(f"### Market Data for District: **{district}**")
                    if len(market_data) > 0:
                        st.info(f"Total records found: {len(market_data)}")
                        # Display data in an interactive table
                        st.dataframe(pd.DataFrame(market_data))
                        # Show key statistics
                        st.write("### Highlights")
                        avg_price = pd.DataFrame(market_data).get("modal_price", pd.Series()).astype(float).mean()
                        st.metric("Average Price", f"₹{avg_price:.2f}" if not pd.isnull(avg_price) else "N/A")
                    else:
                        st.warning("No data available for the selected district.")
                else:
                    st.error("No market data found or an error occurred.")

        elif search_option == "Commodity":
            commodity = st.text_input("Enter commodity name (e.g., rice, wheat, etc.)")
            if commodity:
                commodity_data = fetch_commodity_data(commodity)
                if commodity_data:
                    st.write(f"### Market Data for Commodity: **{commodity}**")
                    if len(commodity_data) > 0:
                        st.info(f"Total records found: {len(commodity_data)}")
                        st.dataframe(pd.DataFrame(commodity_data))
                        # Show key statistics
                        st.write("### Highlights")
                        avg_price = pd.DataFrame(commodity_data).get("modal_price", pd.Series()).astype(float).mean()
                        st.metric("Average Price", f"₹{avg_price:.2f}" if not pd.isnull(avg_price) else "N/A")
                    else:
                        st.warning("No data available for the selected commodity.")
                else:
                    st.error("No market data found or an error occurred.")

    elif choice == "Product News":
        st.subheader("Fetch News Articles for Products")

        product_name = st.text_input("Enter the product name to search for news:")

        if st.button("Fetch News"):
            if product_name:
                api_key = "143716419f1241a0ac09f7a77e3f1576"  # Replace with your News API key
                news_articles = fetch_news_articles(product_name, api_key)

                if news_articles:
                    st.write(f"### News articles related to '{product_name}':")
                    for article in news_articles[:10]:  # Limit to 10 articles for display
                        st.markdown(f"**Title:** {article['title']}")
                        st.markdown(f"**Description:** {article['description']}")
                        st.markdown(f"[Read More]({article['url']})\n---")
                else:
                    st.warning(f"No news articles found for '{product_name}'.")
            else:
                st.warning("Please enter a product name.")

if __name__ == "__main__":
    main()
