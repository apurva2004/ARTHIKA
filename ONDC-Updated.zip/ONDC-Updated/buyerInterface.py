import streamlit as st
from pymongo import MongoClient
from bson.objectid import ObjectId

# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')
db = client['ondc_products']
collection = db['products']
orders_collection = db['orders']
def update_missing_categories():
    # Update documents that do not have the 'categories' field
    collection.update_many(
        {'categories': {'$exists': False}},  # Check for products missing the 'categories' field
        {'$set': {'categories': []}}  # Add an empty list as the default value
    )
    print("Missing categories field has been updated in documents.")

# Run this function to ensure all documents have 'categories' field
update_missing_categories()
# Fetch all categories
def get_all_categories():
    return sorted(collection.distinct('category'))

# Fetch products by category
def get_products_by_category(category):
    return list(collection.find({'category': category}))

# Place an order
def place_order(product_id, buyer_name, quantity):
    # Fetch product by ID
    product = collection.find_one({'_id': ObjectId(product_id)})
    
    if product:
        available_quantity = product.get('quantity', 0)  # Get quantity from product
        if available_quantity >= quantity:
            # Ensure 'categories' field is present before proceeding
            if 'categories' not in product:
                product['categories'] = []  # Assign an empty list or default value
            
            # Update product quantity
            collection.update_one(
                {'_id': ObjectId(product_id)},
                {'$inc': {'quantity': -quantity}}  # Decrement the quantity
            )
            print("The category is:", product['categories'])

            # Create the order record
            order = {
                'buyer_name': buyer_name,
                'product_name': product['product_name'],
                'quantity': quantity,
                'total_price': product['price'] * quantity,
                'categories': product['categories']  # Ensure categories are included
            }
            
            orders_collection.insert_one(order)
            return True, order
    
    return False, None



def main():
    st.title("Buyer Interface for ONDC-like Platform")

    # Buyer details
    st.sidebar.header("Buyer Details")
    buyer_name = st.sidebar.text_input("Enter your name")

    # Display categories
    categories = get_all_categories()
    selected_category = st.selectbox("Select a category", categories)

    if selected_category:
        products = get_products_by_category(selected_category)
        st.write(f"Products in category '{selected_category}':")

        for product in products:
            col1, col2 = st.columns([3, 1])
            with col1:
                st.write(f"**{product['product_name']}**")
                st.write(f"Price: ₹{product['price']}")
                stock = product.get('quantity', 0)  # Default to 0 if stock field is missing
                st.write(f"Stock: {stock if stock > 0 else 'Out of stock'}")  # Display 'Out of stock' if stock is 0 or missing
            with col2:
                # Ensure quantity is valid and does not exceed stock
                quantity = st.number_input(
                    f"Quantity for {product['product_name']}",
                    min_value=0,
                    max_value=stock,  # Prevent input greater than stock
                    value=0,  # Default value is 0
                    step=1,  # Increment in steps of 1
                    key=str(product['_id'])
                )
                if st.button(f"Buy {product['product_name']}", key=f"buy_{product['_id']}"):
                    if not buyer_name.strip():
                        st.error("Please enter your name in the sidebar.")
                    elif quantity > stock:
                        st.error(f"Insufficient stock for {product['product_name']}.")
                    elif quantity == 0:
                        st.error(f"Quantity must be greater than 0.")
                    else:
                        success, order = place_order(product['_id'], buyer_name, quantity)
                        if success:
                            st.success(
                                f"Order placed! You bought {quantity} x {product['product_name']} for ₹{order['total_price']}."
                            )
                        else:
                            st.error("Order failed. Please try again.")

    # View order history
    if st.sidebar.button("View Order History"):
        orders = list(orders_collection.find({'buyer_name': buyer_name}))
        if orders:
            st.sidebar.write(f"Order history for {buyer_name}:")
            for order in orders:
                st.sidebar.write(f"{order['quantity']} x {order['product_name']} - ₹{order['total_price']}")
        else:
            st.sidebar.write("No orders found.")

if __name__ == "__main__":
    main()
